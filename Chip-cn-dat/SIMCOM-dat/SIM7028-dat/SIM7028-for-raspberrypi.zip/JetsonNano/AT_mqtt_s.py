import time
import serial
import json
import threading
import os

ser = serial.Serial('/dev/ttyTH1', baudrate=115200, timeout=1)  # 树莓派 zero 2w串口控制选择/dev/ttyS0

ID = ""  # 请填入Client ID
sub = ""  # 请填入订阅地址
pub = ""  # 请填入发布地址

mqtt_server = "mqtt.waveshare.cloud"

isSerial2Available = True
isMqtt = True

startSent = False


def powerLed(swatch):
    led = open('/sys/class/leds/pwr/brightness', 'w', 1)
    led.write(str(swatch))
    led.close()


def getLed():
    led = open('/sys/class/leds/pwr/brightness', 'r', 1)
    state = led.read()
    led.close()
    return state


def getDevice():
    ser.write(b'AT\r\n')
    time.sleep(0.1)
    response = ser.read_all().decode()
    if "OK" in response:
        print("Got Sim7208!")
    else:
        print("Serial Device Not Found! Retrying...")


def SentMessage(p_char):
    global isSerial2Available
    ser.write(p_char.encode() + b'\r\n')
    time.sleep(1)

    response = ser.read_all().decode()
    responses = response.split('\r\n')
    for resp in responses:
        if "+CREG: 0," in resp:
            status = int(resp.split("+CREG: 0,")[1])
            if status == 6:
                isSerial2Available = False
                print("\nNetWork Connected")
        elif "+CMQTTCONNECT: 0," in resp:
            status = int(resp.split("+CMQTTCONNECT: 0,")[1])
            if status == 0:
                isSerial2Available = False
                print("\nMqtt Connected")
            elif status == 23:
                isSerial2Available = False
                print("\nMqtt is already Connected")


def input_message(p_char, p_data):
    global startSent
    ser.write(p_char.encode() + b'\r\n')
    time.sleep(0.2)
    ser.write(p_data.encode() + b'\r\n')
    time.sleep(1)

    response = ser.read_all().decode()
    responses = response.split('\r\n')
    for resp in responses:
        if "+CMQTTSUB: 0," in resp:
            status = int(resp.split("+CMQTTSUB: 0,")[1])
            if status == 0:
                print("\nSubTopic Sub")
                startSent = True
                thread_Start()


def getResponseData():
    while True:
        buffer = b''
        while ser.in_waiting:
            c = ser.read(1)
            if c == b'\r':
                continue
            if c == b'\n':
                buffer = buffer.strip()
                if not buffer.startswith(b'+CMQTTPUB: 0,0') and buffer != b'OK':
                    if b'{' in buffer:
                        try:
                            jsonDocument = json.loads(buffer.decode())
                            ledValue = jsonDocument.get('data', {}).get('LED')
                            if ledValue == 1:
                                print("LED is HIGH")
                                powerLed(1)
                                sent_mqtt()
                            elif ledValue == 0:
                                print("LED is LOW")
                                powerLed(0)
                                sent_mqtt()
                        except json.JSONDecodeError:
                            print("JSON parsing failed!")
                buffer = b''
            else:
                buffer += c


def setup():
    global isSerial2Available
    getDevice()
    ser.write(b'AT+CSQ\r\n')

    while isSerial2Available:
        SentMessage("AT+CREG?")
        time.sleep(1)
    isSerial2Available = True
    time.sleep(0.5)
    SentMessage('AT+CMQTTSTART\r\n')
    time.sleep(1)
    connect_cmd = "AT+CMQTTACCQ=0,{},0".format(ID)
    SentMessage(connect_cmd + '\r\n')
    time.sleep(0.5)
    while isSerial2Available:
        connect_cmd = "AT+CMQTTCONNECT=0,tcp://{}:1883,20,1".format(mqtt_server)
        SentMessage(connect_cmd + '\r\n')
        # ser.write(connect_cmd.encode() + b'\r\n')
        time.sleep(1)
    dataLength = str(len(pub))
    connect_cmd = "AT+CMQTTTOPIC=0,{}".format(dataLength)
    input_message(connect_cmd, pub)

    time.sleep(2)

    dataLength = str(len(sub))
    connect_cmd = "AT+CMQTTSUB=0,{},0".format(dataLength)
    input_message(connect_cmd, sub)


def thread_Start():
    thread_response = threading.Thread(target=getResponseData)
    thread_response.daemon = True
    thread_response.start()


def sent_mqtt():
    global startSent
    # 获取指示灯状态
    power_stats = int(getLed())
    if (power_stats == 0):
        power_LED = 0
    else:
        power_LED = 1
    # 构建与云端模型一致的消息结构
    updateMsn = {'data': {
        'Led_status': power_LED
    }}
    print(updateMsn)
    dataLength = str(len(str(updateMsn)))
    if startSent:
        connect_cmd = "AT+CMQTTPAYLOAD=0,{}".format(dataLength)
        input_message(connect_cmd, str(updateMsn))

        time.sleep(0.5)
        ser.write(b'AT+CMQTTPUB=0,0,120\r\n')


def main():
    setup()

    while True:
        time.sleep(3)
        sent_mqtt()


if __name__ == "__main__":
    main()
