import time
import serial
import json
import threading

ser = serial.Serial('COM49', baudrate=115200, timeout=1)

ID = ""
sub = ""
pub = ""

mqtt_server = "mqtt.waveshare.cloud"

isSerial2Available = True
isMqtt = True


def getDevice():
    ser.write(b'AT\r\n')
    time.sleep(0.1)
    response = ser.read_all().decode()
    if "OK" in response:
        print("Got Sim7208!")
        global isSerial2Available
        isSerial2Available = False
    else:
        print("Serial Device Not Found! Retrying...")


def SentMessage(p_char):
    global isSerial2Available
    ser.write(p_char.encode() + b'\r\n')
    time.sleep(1)

    response = ser.read_all().decode()
    responses = response.split('\r\n')
    print(responses)
    for resp in responses:
        if "+CREG: 0," in resp:
            status = int(resp.split("+CREG: 0,")[1])
            if status == 6:
                isSerial2Available = False
                print("\nNetWork Connected")
        elif "+CMQTTCONNECT: 0," in resp:
            status = int(resp.split("+CMQTTCONNECT: 0,")[1])
            if status == 0:
                isSerial2Available = False
                print("\nMqtt Connected")
            elif status == 23:
                isSerial2Available = False
                print("\nMqtt is already Connected")


def input_message(p_char, p_data):
    ser.write(p_char.encode() + b'\r\n')
    time.sleep(0.2)
    ser.write(p_data.encode() + b'\r\n')
    time.sleep(1)

    response = ser.read_all().decode()
    if "OK" in response:
        print("Write OK")
    elif "ERROR" in response:
        print("Write ERROR")


def getResponseData():
    while True:
        buffer = b''
        while ser.in_waiting:
            c = ser.read(1)
            if c == b'\r':
                continue
            if c == b'\n':
                buffer = buffer.strip()
                if not buffer.startswith(b'+CMQTTPUB: 0,0') and buffer != b'OK':
                    if b'{' in buffer:
                        try:
                            jsonDocument = json.loads(buffer.decode())
                            ledValue = jsonDocument.get('data', {}).get('LED')
                            if ledValue == 1:
                                print("LED is HIGH")
                            elif ledValue == 0:
                                print("LED is LOW")
                        except json.JSONDecodeError:
                            print("JSON parsing failed!")
                buffer = b''
            else:
                buffer += c


def setup():
    ser.write(b'AT+CSQ\r\n')

    while isSerial2Available:
        SentMessage("AT+CREG?")
        time.sleep(1)

    ser.write(b'AT+CMQTTSTART\r\n')
    connect_cmd = "AT+CMQTTACCQ=0,{},0".format(ID)
    ser.write(connect_cmd.encode() + b'\r\n')
    connect_cmd = "AT+CMQTTCONNECT=0,tcp://{}:1883,20,1".format(mqtt_server)
    ser.write(connect_cmd.encode() + b'\r\n')

    dataLength = str(len(pub))
    connect_cmd = "AT+CMQTTTOPIC=0,{}".format(dataLength)
    input_message(connect_cmd, pub)
    time.sleep(1)

    dataLength = str(len(pub))
    connect_cmd = "AT+CMQTTSUB=0,{},0".format(dataLength)
    input_message(connect_cmd, sub)

    time.sleep(2)
    msgdata = "This is Sim7028 with Arduino!"
    dataLength = str(len(msgdata))
    connect_cmd = "AT+CMQTTPAYLOAD=0,{}".format(dataLength)
    input_message(connect_cmd, msgdata)
    time.sleep(1)


def main():
    setup()

    thread_response = threading.Thread(target=getResponseData)
    thread_response.daemon = True
    thread_response.start()

    while True:

        # msgdata = "This is Sim7028 with Arduino!"
        # dataLength = str(len(msgdata))
        # connect_cmd = "AT+CMQTTPAYLOAD=0,{}".format(dataLength)
        # input_message(connect_cmd, msgdata)
        connect_cmd = "AT+CMQTTPUB=0,0,60"
        SentMessage(connect_cmd)
        time.sleep(5)


if __name__ == "__main__":
    main()
