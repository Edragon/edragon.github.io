#include "sfr_r81B.h"
#include "var_def.h"
#include "interrupt.h"
#include "systerm_init.h"
#include "led.h"
#include "key.h"


unsigned char key_read(void)
{ 
	
	KEY_X1=0;KEY_X2=1;KEY_X3=1;KEY_X4=1;
	if(KEY_Y1==0){return 1;}
	if(KEY_Y2==0){return 2;}
	if(KEY_Y3==0){return 3;}
	if(KEY_Y4==0){return 0xf1;}
	KEY_X1=1;KEY_X2=0;KEY_X3=1;KEY_X4=1;
	if(KEY_Y1==0){return 4;}
	if(KEY_Y2==0){return 5;}
	if(KEY_Y3==0){return 6;}
	if(KEY_Y4==0){return 0xf2;}
	KEY_X1=1;KEY_X2=1;KEY_X3=0;KEY_X4=1;
	if(KEY_Y1==0){return 7;}
	if(KEY_Y2==0){return 8;}
	if(KEY_Y3==0){return 9;}
	if(KEY_Y4==0){return 0xf3;}
	KEY_X1=1;KEY_X2=1;KEY_X3=1;KEY_X4=0;
	if(KEY_Y1==0){return 10;}
	if(KEY_Y2==0){return 11;}
	if(KEY_Y3==0){return 12;}
	if(KEY_Y4==0){return 0xf4;}	
	return 0;
}

