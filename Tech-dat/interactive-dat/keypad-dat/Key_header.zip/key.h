#ifndef KEY_H
#define KEY_H

#define 	KEY_Y1		p1_0
#define 	KEY_Y2		p1_1
#define 	KEY_Y3		p1_2
#define 	KEY_Y4		p1_3
#define 	KEY_X1		p1_4
#define 	KEY_X2		p1_5
#define 	KEY_X3		p1_6
#define 	KEY_X4		p1_7



unsigned char key_read(void);


#endif