
#include "qst_sw_i2c.h"
#include "bsp_usart.h"
#include "math.h"



#define MT6813_IIC_ADDR               0x0C //0x0D //0x1a
#define fabs(x)                    (x < 0 ? -x : x)
float angle_pre;

uint8_t MT6813_read_reg(uint8_t Addr, uint8_t* Buf, uint8_t Len)
{
	uint8_t ret = 0;
	uint32_t retry = 0;

	while((!ret)&&(retry++ < 5))
	{
    ret = qst_sw_readreg(MT6813_IIC_ADDR, Addr, Buf, Len);
	}
	return ret;
}


static int MT6813_read_block(uint8_t addr, uint8_t *data, uint8_t len)
{
	uint8_t ret = 0;
	uint32_t retry = 0;

	while((!ret)&&(retry++ < 5))
	{
    ret = qst_sw_readreg(MT6813_IIC_ADDR, addr, data, len);
	}
	return ret;
}


static int MT6813_write_reg(uint8_t addr, uint8_t data)
{	
	uint8_t ret = 0;
	uint32_t retry = 0;

	while((!ret)&&(retry++ < 5))
	{
		ret = qst_sw_writereg(MT6813_IIC_ADDR, addr, data);
	}
	return ret;
}

void MT6701_INIT(void)
{
	uint8_t Buff[2];
	MT6813_read_reg(0x22, &Buff[0], 2);
	if(Buff[0] == 0x60)
	{
		printf("RG 0x22=%x\r\n",Buff[0]);
		return;
	}
	MT6813_write_reg(0x22, 0x60);  // PGA-GAIN д6
	MT6813_write_reg(0x24, 0x80);  // AGC-DISд1
	MT6813_write_reg(0x27, 0xB8);  
	MT6813_read_reg(0x22, &Buff[0], 2);
	printf("RG 0x22 C=%x\r\n",Buff[0]);
	MT6813_read_reg(0x24, &Buff[0], 2);
	printf("RG 0x24 D=%x\r\n",Buff[0]);
	
	//save eeprom
	MT6813_write_reg(0x09, 0xB3);
	MT6813_write_reg(0x0A, 0x05);
}


short angle_now;
short MT6701_GetData(uint8_t *Magnet)
{
	uint8_t Buff[6];
	int data;
	
	float angle;
	MT6813_read_reg(0x03, &Buff[0], 2);

	Magnet[0] = Buff[0];
	Magnet[1] = Buff[1];

	data = (short)((Magnet[0]<<8)|(Magnet[1]));
	data = data>>2;
	angle = (float)(data*0.022);
	if(angle<0)
	{
		angle = 360+angle;
	}
	
	// if((short)angle != angle_now)
	// {
		
	// 	angle_now = (short)angle;
	// 	printf("angle=%d\r\n",angle_now);
	// }
	

	return angle_now;
}

uint8_t Zero_point_programming(void)
{
	uint8_t Buff[2],ZH,ZL;
	int data��zero;
	
	//�����Ĵ���
	MT6813_read_reg(0x32 &Buff[0], 2);
	ZH = Buff[0] & 0xf0;
	MT6813_write_reg(0x32, ZH);
	MT6813_write_reg(0x33, 0x00);

	MT6813_read_reg(0x03, &Buff[0], 2);

	data = (short)((Buff[0]<<8)|(Buff[1]));
	data = data>>2;  //14bit
	data = data>>2;  //12bit

	ZH = ZH | (uint8_t)(data >> 8) 
	ZL = (uint8_t)(data & 0x0f) 

	MT6813_write_reg(0x32, ZH);
	MT6813_write_reg(0x33, ZL);

	//save eeprom
	MT6813_write_reg(0x09, 0xB3);
	MT6813_write_reg(0x0A, 0x05);

	MT6813_read_reg(0x32, &Buff[0], 2);

	if((Buff[0] == ZH) && (Buff[1] == ZL))
	{
		return 1;
	}

	return 0;
	
}