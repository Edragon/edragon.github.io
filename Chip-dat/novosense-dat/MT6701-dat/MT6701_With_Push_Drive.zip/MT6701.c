
#include "qst_sw_i2c.h"
#include "bsp_usart.h"
#include "math.h"



#define MT6701_IIC_ADDR               0x0C //0x0D //0x1a


uint8_t MT6701_read_reg(uint8_t Addr, uint8_t* Buf, uint8_t Len)
{
	uint8_t ret = 0;
	uint32_t retry = 0;

	while((!ret)&&(retry++ < 5))
	{
    ret = qst_sw_readreg(MT6701_IIC_ADDR, Addr, Buf, Len);
	}
	return ret;
}


static int MT6701_write_reg(uint8_t addr, uint8_t data)
{	
	uint8_t ret = 0;
	uint32_t retry = 0;

	while((!ret)&&(retry++ < 5))
	{
		ret = qst_sw_writereg(MT6701_IIC_ADDR, addr, data);
	}
	return ret;
}

void MT6701_INIT(void)
{
	uint8_t Buff;
	MT6701_write_reg(0x22, 0xd1);  	// PGA-GAIN д0x0d

	MT6701_read_reg(0x24, &Buff, 1); //�ȶ���0x24�Ĵ�����ֵȻ�����λAGC-DISд1����д��0x24�Ĵ�����
	Buff = Buff | 0x80;  						//���λAGC-DISд1
	MT6701_write_reg(0x24, Buff);  

	MT6701_read_reg(0x22, &Buff, 1);
	printf("RG 0x22 =0x%x\r\n",Buff);  //��ȷֵΪ0xD1
	MT6701_read_reg(0x24, &Buff, 1);
	printf("RG 0x24 =0x%x\r\n",Buff);  //��ȷֵΪ0x8X,���λҪд1
}


short MT6701_GetData(uint8_t *Magnet)
{
	uint8_t Buff[2];
	int data;
	
	float angle;
	MT6701_read_reg(0x03, &Buff[0], 2);

	Magnet[0] = Buff[0];
	Magnet[1] = Buff[1];

	data = (short)((Magnet[0]<<8)|(Magnet[1]));
	data = data>>2;
	angle = (float)(data*0.022);
	if(angle<0)
	{
		angle = 360+angle;
	}
	
	return angle;
}


uint16_t MT6701_Get_CORDIC_RAD(void)
{
	uint8_t data_buffer[2];
	uint16_t Cor_rads;
	MT6701_read_reg(0x54,&data_buffer[0],2);
	Cor_rads = data_buffer[0]*16+(data_buffer[1]>>4);
	return Cor_rads;
}